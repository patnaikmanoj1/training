package com.exam.training.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.training.model.Product;

@RestController
public class TrainingController {
	
	List<Product> sortedList = new ArrayList<Product>();
	

	@PostMapping(path="/sortProduct")
	@ResponseBody
	public List<Product> sortProduct(@RequestBody ArrayList<Product> productList) {
		
		Comparator<Product> compareByIdDate = Comparator
                .comparing(Product::getProductId)
                .thenComparing(Product::getLaunchDate);
		
		sortedList = productList.stream()
                .sorted(compareByIdDate.reversed())
                .collect(Collectors.toList());
		
		return sortedList;
	}

}
